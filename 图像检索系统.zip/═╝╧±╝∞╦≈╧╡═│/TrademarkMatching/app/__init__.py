import sys

import time
from werkzeug.utils import secure_filename
from flask import Flask, render_template, request, redirect, url_for
import searchImgSpark

#import searchImg

app = Flask(__name__)


# 主页部分
@app.route('/', methods=["GET", "POST"])
def index():
    print('Welcome search page!')
    if request.method == "POST":
        try:
            image = request.files['file']
        except Exception as e:
            print('Exception:', e)
            return render_template('index.html')
        else:
            filename = '%s%s' % (int(time.time()), secure_filename(image.filename))
            print('--------', filename)
            image.save(sys.path[0] + '/app/static/queryImg/' + filename)
            return redirect(url_for('search', filename=filename))
    else:
        return render_template('index.html')


# 搜索页面部分
@app.route('/searchs/<filename>', methods=['POST', 'GET'])
def search(filename):
    print('Begin search .....')
    path = sys.path[0] + '/app/static/queryImg/' + filename
    #results = searchImg.SearcherImg(path).deture_detect()
    results =searchImgSpark.SearcherImgOfSpark(path).deture_detect()
    print("-----:", results)
    # 传递参数给html
    return render_template('result.html', results=results, filename=filename)
