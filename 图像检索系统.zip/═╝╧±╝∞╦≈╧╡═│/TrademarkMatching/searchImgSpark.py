import cv2
import socket
from lake.decorator import time_cost

from processImg import extract_feature, resize_image


class SearcherImgOfSpark(object):
    def __init__(self, queryImage):
        self.results = []
        self.path = queryImage
        self.queryImage = resize_image(cv2.imread(queryImage))
        _, self.des = extract_feature(self.queryImage)
        self.client = socket.socket()
        self.client.connect(('192.168.0.237', 9999))  # 连接服务器

    @time_cost
    def deture_detect(self):
        msg = repr(self.des.tolist())
        self.client.send(msg.encode())
        self.client.send('END'.encode())
        data = self.client.recv(1024)
        print(data)
        print("接收结果：", data.decode())
        self.results = eval(data.decode())
        self.client.close()

        results = []
        for n in self.results:
            results.append(n[1])
            cv2.imwrite('./app/static/query/' + n[1], resize_image(cv2.imread('../ningboshi/data/' + n[1])))
        return results
