import cv2


def extract_feature(image):
    sift = cv2.xfeatures2d.SIFT_create()
    return sift.detectAndCompute(image, None)


def resize_image(image, weight=500, height=500):
    image = cv2.resize(cv2.cvtColor(image, cv2.COLOR_BGR2GRAY), (weight, height), interpolation=cv2.INTER_LANCZOS4)
    return image
