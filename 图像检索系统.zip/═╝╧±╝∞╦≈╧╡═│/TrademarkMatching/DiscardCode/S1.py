import socketserver

class MyTCPHandler(socketserver.BaseRequestHandler):  #创建一个继承BaseRequestHandler的请求处理类
    def handle(self):   #重写BaseRequestHandler类中的handle()函数
        while True:
            try:     #抓取异常
                self.data=self.request.recv(100).strip()
                print(len(self.data))
                print("wrote:{}".format(self.client_address[0])) #不懂
                print(self.client_address)
                print(self.data)
                print(self.data.upper())
                print('-------------------')
                self.request.send(self.data.upper())
            except ConnectionResetError as e:
                print("error:",e)
                break
if __name__=="__main__":
    HOST,PORT="192.168.0.237",9991
    server=socketserver.ThreadingTCPServer((HOST,PORT),MyTCPHandler)   #实例化TCPServer且传递server ip地址，端口和上面所创建的请求处理类  Threading线程实现并发
    server.serve_forever()    #处理多个请求