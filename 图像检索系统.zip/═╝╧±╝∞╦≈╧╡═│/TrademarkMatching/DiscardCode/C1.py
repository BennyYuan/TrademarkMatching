import socket

client=socket.socket()
client.connect(("192.168.0.237",9991))


while True:
    msg=input(">>:").strip()
    if len(msg)==0:continue
    client.send(msg.encode())
    data=client.recv(10240)
    print("接收结果：",data.decode())

client.close()