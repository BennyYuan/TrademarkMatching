import json
import socketserver
import time

import cv2
import numpy as np
from pyspark import SparkContext

logFile = "ningbo_data.json"
print("开始等待接受客户端数据----")
sc = SparkContext('local[*]', 'sparkTop')
logData = sc.textFile(logFile, 5)
logjson = logData.map(lambda s: json.loads(s))


class MyTCPHandler(socketserver.BaseRequestHandler):
    def handle(self):
        start = time.time()
        recv_msg = ""
        END = True
        while END:
            try:
                self.data = self.request.recv(1024).decode()
                if len(self.data) == 0:
                    continue
                elif self.data[-1] == "D":
                    END = False
                recv_msg = recv_msg + self.data
            except ConnectionResetError as e:
                print("error:", e)
                break
        feature = np.array(eval(recv_msg.strip("END"))).astype(np.float32)
        des = sc.broadcast(feature)
        print('\n\nbroadcast:', des, des.value, self.client_address)
        logData = logjson.map(lambda x: (compute_score(des, np.array(x["feature"]).astype(np.float32)), x["path"]))
        a = logData.top(10)
        print('\n', self.client_address, a)
        self.request.sendall(str(a).encode())
        print(time.time() - start)


def compute_score(des, imgS):
    matches = cv2.BFMatcher().knnMatch(des.value, imgS, k=2)
    length = len([m for m, n in matches if m.distance < 0.75 * n.distance])
    return length


if __name__ == "__main__":
    HOST, PORT = "192.168.0.237", 9999
    server = socketserver.ThreadingTCPServer((HOST, PORT), MyTCPHandler)
    server.serve_forever()
